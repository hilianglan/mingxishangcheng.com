<?php

/**
 * 到货通知
 */
$lang['arrivalnotice_arrivalnotice'] = '到货通知';
$lang['arrivalnotice_member_name'] = '会员用户名';
$lang['arrivalnotice_mobile'] = '手机';
$lang['arrivalnotice_state'] = '通知状态';
$lang['arrivalnotice_state_1'] = '未通知';
$lang['arrivalnotice_state_2'] = '已通知';
$lang['arrivalnotice_addtime'] = '登记时间';
$lang['arrivalnotice_time'] = '通知时间';
$lang['arrivalnotice_noinformed'] = '未通知';
$lang['arrivalnotice_informed'] = '已通知';
$lang['arrivalnotice_tips'] = '您可以通过填写商品名称来直接搜索您想要找的商品，或者是选择通知状态来选择该状态所属的所有商品。';

return $lang;

<?php

$lang['goodsvideo'] = '视频';

return $lang;
?>

<?php
/**
 * 日志记录
 */
$lang['account_synchronous_login']		= '编辑账号同步，微信登录设置';

/**
 * 栏目信息
 */
$lang['qq_interconnection']		= 'QQ 互联';
$lang['sina_interconnection']		= '微博 互联';
$lang['wx_login']		= '微信登录';
$lang['account_setting']		= '设置';
$lang['auto_register']		= '自动注册';

return $lang;








<?php

return [
    'storegrade_name'=>'等级名称',
    'storegrade_goods_limit'=>'可发布商品数',
    'storegrade_album_limit'=>'可上传图片数',
    'storegrade_space_limit'=>'可使用空间大小',
    'storegrade_template_number'=>'可选模板套数',
    'storegrade_template'=>'可选模板',
    'storegrade_price'=>'收费标准',
    'storegrade_confirm'=>'是否审核',
    'storegrade_description'=>'申请说明',
    'storegrade_sort'=>'等级级别',
    'store_grade_name' => '等级名称',
    'now_store_grade_name_is_there'=>'该等级名称已经存在，请您换一个',
    'add_gradesortexist'=>'级别已经存在',
    'default_store_grade_no_del'=>'默认等级不能删除',
    'del_gradehavestore'=>'请先删除该店铺等级下的店铺信息',
    'storegrade_drop_confrim'=>'您确定删除此店铺等级',
];
?>

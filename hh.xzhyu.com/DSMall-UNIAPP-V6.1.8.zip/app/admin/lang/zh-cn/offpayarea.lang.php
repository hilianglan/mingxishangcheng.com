<?php

$lang['offpayarea_index_help1'] = '注意：此处是设置平台自营店铺支持货到付款的地区，只有开启货到付款时以下设置的地区才能使用货到付款';
$lang['offpayarea_index_help2'] = '选择完子地区确认后，需要点击页面底部的保存按钮系统才会保存设置的地区';


$lang['offpayarea_province'] = '省';
$lang['offpayarea_city'] = '市';

$lang['selected_sub_areas'] = '已选下级地区';
$lang['select_sub_areas'] = '已选下级地区';


$lang['no_child_region'] = '下面没有子地区，无需要编辑';
$lang['select'] = '选择';
$lang['child_region'] = '子地区';

return $lang;
<?php

$lang['already_logged'] = '已经登录';
$lang['login_succ'] = '登录成功';
$lang['login_error'] = '账号密码错误';
$lang['logout_succ'] = '退出成功';

return $lang;
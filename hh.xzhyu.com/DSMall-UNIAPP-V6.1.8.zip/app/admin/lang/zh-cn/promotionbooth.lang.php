<?php

$lang['booth_quota_help1'] = '卖家购买推荐展位的列表';
$lang['booth_index_help1'] = '被推荐商品将在该商品所在的商品分类和其上级的商品分类的商品列表页面的左侧随机出现';
$lang['promotion_booth_price'] = '推荐展位价格';
$lang['promotion_booth_price_tips'] = '购买单位为月(30天)，购买后卖家可以在所购买周期内推荐商品，在商品列表热卖商品中随机显示。';
$lang['promotion_booth_goods_sum'] = '允许的最大数量';
$lang['promotion_booth_goods_sum_tips'] = '每个店铺推荐商品的最大数量。';

$lang['goods_list'] = '商品列表';
$lang['booth_list'] = '套餐列表';

return $lang;

<?php

$lang['link_sort'] = '排序';
$lang['link_title'] = '合作伙伴';
$lang['link_url'] = '链接';
$lang['link_pic'] = '图片标识';

$lang['link_add_title_null'] = '合作伙伴标题不能为空';
$lang['link_add_url_wrong'] = '链接格式不正确';
$lang['link_add_name'] = '合作伙伴的名称';
$lang['link_add_href'] = '合作伙伴的链接地址';
$lang['link_add_sign'] = '合作伙伴的标志图片';
$lang['link_add_tosign'] = '当前为文字链接，如有合作伙的LOGO，请重新上传标志图片';
$lang['link_add_sort_tip'] = '数字越小越靠前';
$lang['link_add_url_null'] = '请填写合作伙伴的链接地址';
$lang['link_index_title'] = '标题';

$lang['link_index_help1'] = '通过友情链接您可以，编辑、查看、删除合作伙伴信息';

return $lang;


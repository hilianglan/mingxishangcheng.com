<?php

$lang['get_minipro_access_token_fail'] = '获取小程序AccessToken失败';
$lang['del_goods_fail'] = '删除商品出错，错误码：';
$lang['goods_not_exist'] = '商品不存在';
$lang['apply_switch'] = '申请开关';
$lang['ensure_open'] = '确定要开启吗？';
$lang['ensure_close'] = '确定要关闭吗？';
$lang['goods_apply_pass'] = '已通过';
$lang['goods_apply_reject'] = '未通过';
$lang['goods_apply_wait'] = '审核中';
return $lang;
<?php
return [
    'nav_sort' => '排序',
    'nav_title' => '标题',
    'nav_url' => '导航链接',
    'nav_location' => '导航位置',
    'nav_new_open' => '新窗口打开',
    'nav_sort_error' => '排序只能为数字',
    'nav_title_error' => '标题不能为空',
    'nav_top' => '头部',
    'nav_midd' => '中部',
    'nav_foo' => '底部',
];
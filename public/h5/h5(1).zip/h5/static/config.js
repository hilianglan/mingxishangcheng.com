export const env = {
  'H5_HOST': 'https://sh.mingxishangcheng.com/h5',
  'SELLER_H5_HOST': 'https://sh.mingxishangcheng.com/h5',
  'API_HOST': 'https://sh.mingxishangcheng.com/api',
  'SITE_URL': 'https://sh.mingxishangcheng.com',
  'DEBUG': true,
  'ENCRYPTED': false,
  'BMAP_AK': '0d2B53HCO8ciBB5fz9NmHU3GVGP71qBH',
  'BMAP_AK_BRO': '22bb7221fc279a484895afcc6a0bb33a',
}
